/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#ifdef __GNUC__
  /* With GCC, small printf (option LD Linker->Libraries->Small printf
     set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */
void TDC7200_SPIByteWriteReg(uint8_t addr, uint8_t value);
/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/************************************************************
* TDC7200 REGISTER SET ADDRESSES
************************************************************/

#define TDC7200_CONFIG1_REG						0x00
#define TDC7200_CONFIG2_REG						0x01
#define TDC7200_INTRPT_STATUS_REG				0x02
#define TDC7200_INTRPT_MASK_REG					0x03
#define TDC7200_COARSE_COUNTER_OVH_REG			0x04
#define TDC7200_COARSE_COUNTER_OVL_REG			0x05
#define TDC7200_CLOCK_COUNTER_OVH_REG			0x06
#define TDC7200_CLOCK_COUNTER_OVL_REG			0x07
#define TDC7200_CLOCK_COUNTER_STOP_MASKH_REG	0x08
#define TDC7200_CLOCK_COUNTER_STOP_MASKL_REG	0x09

#define TDC7200_TIME1_REG						0x10
#define TDC7200_CLOCK_COUNT1_REG				0x11
#define TDC7200_TIME2_REG						0x12
#define TDC7200_CLOCK_COUNT2_REG				0x13
#define TDC7200_TIME3_REG						0x14
#define TDC7200_CLOCK_COUNT3_REG				0x15
#define TDC7200_TIME4_REG						0x16
#define TDC7200_CLOCK_COUNT4_REG				0x17
#define TDC7200_TIME5_REG						0x18
#define TDC7200_CLOCK_COUNT5_REG				0x19
#define TDC7200_TIME6_REG						0x1A
#define TDC7200_CALIBRATION1_REG				0x1B
#define TDC7200_CALIBRATION2_REG				0x1C

#define TDC7200_TOTAL_NUM_CONFIG_REG			10
#define TDC7200_TOTAL_NUM_RESULT_REG			39


/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi2;

UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
void TDC7200_reg_init(void);
void tdc_trigger_measure(void);
void TDC1000_SPIByteWriteReg(uint8_t addr, uint8_t value);
void TDC1000_SPIByteReadReg(uint8_t addr,uint8_t *buffer);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART6_UART_Init(void);
/* USER CODE BEGIN PFP */

uint8_t b[3],b0[2],b1[2],b2[2],b3[2],b4[2],b5[2],b6[2],b7[2],b8[2],b9[2],i0[3],i1[3];
uint8_t temp[3];

uint8_t a[3],a0[2],a1[2],a2[2],a3[2],a4[2],a5[2],a6[2],a7[2],a8[2],a9[2];
uint8_t d0[4],d1[4],d2[4],d3[4],d5[4],d6[4];
/* USER CODE END PFP */
uint8_t TDC7200_reg_local_copy[10] = {0x02, 0x44, 0x07, 0x07, 0xFF, 0xFF, 0xFF, 0xFF, 0x0, 0x0 };
uint8_t TDC1000_reg_local_copy[10] = {0x45, 0x41, 0x12, 0x02, 0x1F, 0x88, 0x19, 0x01, 0x23, 0x01};
/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int i=0;
uint8_t byte_data[3];
uint8_t read_data[2];
/* USER CODE END 0 */
uint8_t upStreamBuf[40],downStreamBuf[40];
#define STOP_NUM 5
    
 long int us, ur;
    long int ds, dr;
    long int dn;
    long int dmy;
int flag=0;
long double CLOCKperiod;
long double calCount,normLSB,tof,LSB,mTOF;
long double Q,v,Q1,v1,k=1;
double c=1400;
double l=0.062;

double A=3.14*0.0075*0.0075,dtof;

double d;
    double h,g,h1,g1;
    

    long int uTime[6];
    long int uClk[5];
    long int uCal[2];

    long int dTime[6];
    long int dClk[5];
    long int dCal[2];

 long double TOF[6],T12=0,T21=0,dTOF,mTOF,vel,flow;  



/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
 
  /* USER CODE BEGIN 2 */
	 MX_GPIO_Init();
  MX_SPI2_Init();
  MX_USART6_UART_Init();
	printf("\n\r ================================== \n\r ");
	printf("\n\r       Water Meter Demo \n\r ");
	printf("\n\r ================================== \n\r ");
	printf("\n\rEnabling TDC1000 and TDC7200.... ");
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);//en
HAL_Delay(1000);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);//en

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_RESET);//en
HAL_Delay(1000);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_14, GPIO_PIN_SET);//en		
 //Enable TDC1000



  /* USER CODE END 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		printf("\n\r ============================ \n\r ");
		printf("\n\r Water Meter :Test %d \n\r ",flag+1);
		printf("\n\r ============================ \n\r ");
    /* USER CODE END WHILE */
TDC1000_SPIByteReadReg(0x00,&a0[1]);
TDC1000_SPIByteReadReg(0x01,&a1[1]);
TDC1000_SPIByteReadReg(0x02,&a2[1]);
TDC1000_SPIByteReadReg(0x03,&a3[1]);
TDC1000_SPIByteReadReg(0x04,&a4[1]);
TDC1000_SPIByteReadReg(0x05,&a5[1]);
TDC1000_SPIByteReadReg(0x06,&a6[1]);
TDC1000_SPIByteReadReg(0x07,&a7[1]);
TDC1000_SPIByteReadReg(0x08,&a8[1]);
TDC1000_SPIByteReadReg(0x09,&a9[1]);
	

HAL_Delay(1000);
printf("\n\rConfigure  TDC1000 Registers... ");

TDC1000_SPIByteWriteReg(0x00 ,0x47);
TDC1000_SPIByteWriteReg(0x01 ,0x47);
TDC1000_SPIByteWriteReg(0x02 ,0x12);
TDC1000_SPIByteWriteReg(0x03 ,0x03);
TDC1000_SPIByteWriteReg(0x04 ,0x1F);
TDC1000_SPIByteWriteReg(0x05 ,0x00);
TDC1000_SPIByteWriteReg(0x06 ,0x00);
TDC1000_SPIByteWriteReg(0x07 ,0x03);
TDC1000_SPIByteWriteReg(0x08 ,0x19);
TDC1000_SPIByteWriteReg(0x09 ,0x00);
TDC1000_SPIByteReadReg(0x00,&a0[1]);
TDC1000_SPIByteReadReg(0x01,&a1[1]);
TDC1000_SPIByteReadReg(0x02,&a2[1]);
TDC1000_SPIByteReadReg(0x03,&a3[1]);
TDC1000_SPIByteReadReg(0x04,&a4[1]);
TDC1000_SPIByteReadReg(0x05,&a5[1]);
TDC1000_SPIByteReadReg(0x06,&a6[1]);
TDC1000_SPIByteReadReg(0x07,&a7[1]);
TDC1000_SPIByteReadReg(0x08,&a8[1]);
TDC1000_SPIByteReadReg(0x09,&a9[1]);
printf("\n\rTDC1000 Registers After Initialization:");
printf("\n\r CONFIG_0_REG:0x0%x",a0[1]);
printf("\n\r CONFIG_1_REG:0x0%x",a1[1]);
printf("\n\r CONFIG_2_REG:0x0%x",a2[1]);
printf("\n\r CONFIG_3_REG:0x0%x",a3[1]);
printf("\n\r CONFIG_4_REG:0x0%x",a4[1]);
printf("\n\r TOF_1_REG:0x0%x",a5[1]);
printf("\n\r TOF_0_REG:0x0%x",a6[1]);
printf("\n\r ERROR_FLAGS_REG:0x0%x",a7[1]);
printf("\n\r TIMEOUT_REG:0x0%x",a8[1]);
printf("\n\r CLOCK_RATE_REG:0x0%x",a9[1]);
printf("\n\rConfigure  TDC7200 Registers... ");
TDC7200_reg_init();
/* init registers of TDC7200 */


printf("\n\n\rClear error flags and start Measurement");
printf("\n\rUpstream Measurement");

TDC1000_SPIByteWriteReg(0x07 ,0x03);

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
temp[0]= 0x02;
temp[0]|=(0x40);
temp[1]=0x1F;
HAL_SPI_Transmit(&hspi2,temp ,2, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
HAL_Delay(1000);

//printf("\n\r set start measurement bit");
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b[0]=(0x00)|(0x40);
b[1]=0x03;
HAL_SPI_Transmit(&hspi2,b ,2, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
HAL_Delay(1000);	

HAL_Delay(5000);

printf("\n\r Measurement Done...Calculating TOF ");
printf(" \n\r Reading all the result registers of TDC7200");

//INT status

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
i0[0]=0x02 ;//| 0x40;;
HAL_SPI_Transmit(&hspi2,i0 ,1, 50);
HAL_SPI_Receive(&hspi2,&i0[1],3, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
HAL_Delay(1000);
//Result buffer
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
d6[0]=(0x10)|(0x80);
HAL_SPI_Transmit(&hspi2,d6 ,1, 50);
HAL_SPI_Receive(&hspi2,upStreamBuf,39, HAL_MAX_DELAY);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
HAL_Delay(1000);


printf("\n\rDown stream Measurement");

TDC1000_SPIByteWriteReg(0x07 ,0x03);

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
temp[0]= 0x02;
temp[0]|=(0x40);
temp[1]=0x1F;
HAL_SPI_Transmit(&hspi2,temp ,2, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
HAL_Delay(1000);

//printf("\n\r set start measurement bit");
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b[0]=(0x00)|(0x40);
b[1]=0x03;
HAL_SPI_Transmit(&hspi2,b ,2, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
	

HAL_Delay(8000); //maximum delay between start and stop

printf("\n\r Measurement Done...Calculating TOF ");
printf(" \n\r Reading all the result registers of TDC7200");

//INT status

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
i1[0]=0x02 ;//| 0x40;;
HAL_SPI_Transmit(&hspi2,i1 ,1, 50);
HAL_SPI_Receive(&hspi2,&i1[1],3, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
HAL_Delay(1000);
//Result buffer
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
d6[0]=(0x10)|(0x80);
HAL_SPI_Transmit(&hspi2,d6 ,1, 50);
HAL_SPI_Receive(&hspi2,downStreamBuf,39, HAL_MAX_DELAY);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
HAL_Delay(1000);



////TDC7200_TIME1_REG

//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
//d0[0]=0x10 ;//| 0x40;;
//HAL_SPI_Transmit(&hspi2,d0 ,1, 50);
//HAL_SPI_Receive(&hspi2,&d0[1],3, 50);
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
//HAL_Delay(1000);

////TDC7200_CLOCK_COUNT1_REG
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
//d1[0]=0x11;//| 0x40;
//HAL_SPI_Transmit(&hspi2,d1 ,1, 50);
//HAL_SPI_Receive(&hspi2,&d1[1],3, 50);
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
//HAL_Delay(1000);

////TDC7200_TIME1_REG
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
//d5[0]=0x12;//| 0x40;
//HAL_SPI_Transmit(&hspi2,d5 ,1, 50);
//HAL_SPI_Receive(&hspi2,&d5[1],3, 50);
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
//HAL_Delay(1000);
////TDC7200_CALIBRATION1_REG
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
//d2[0]=0x1B ;//| 0x40;;
//HAL_SPI_Transmit(&hspi2,d2 ,1, 50);
//HAL_SPI_Receive(&hspi2,&d2[1],3, 50);
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
//HAL_Delay(1000);

////TDC7200_CALIBRATION2_REG
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
//d3[0]=0x1C;//| 0x40;
//HAL_SPI_Transmit(&hspi2,d3 ,1, 50);
//HAL_SPI_Receive(&hspi2,&d3[1],3, 50);
//HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
//HAL_Delay(1000);



//tof ccalculation
	for (i=0; i<6; i++)
   {
   	uTime[i]   = 0;
   	uTime[i]   = upStreamBuf[6*i];
   	uTime[i] <<= 8;
   	uTime[i]  += upStreamBuf[6*i + 1];
   	uTime[i] <<= 8;
   	uTime[i]  += upStreamBuf[6*i + 2];

   	dTime[i]   = 0;
   	dTime[i]   = downStreamBuf[6*i];
   	dTime[i] <<= 8;
   	dTime[i]  += downStreamBuf[6*i + 1];
   	dTime[i] <<= 8;
   	dTime[i]  += downStreamBuf[6*i + 2];
   }


   for (i=0; i<5; i++)
   {
   	uClk[i]   = 0;
   	uClk[i]   = upStreamBuf[6*i + 3];
   	uClk[i] <<= 8;
   	uClk[i]  += upStreamBuf[6*i + 4];
   	uClk[i] <<= 8;
   	uClk[i]  += upStreamBuf[6*i + 5];

   	dClk[i]   = 0;
   	dClk[i]   = downStreamBuf[6*i + 3];
   	dClk[i] <<= 8;
   	dClk[i]  += downStreamBuf[6*i + 4];
   	dClk[i] <<= 8;
   	dClk[i]  += downStreamBuf[6*i + 5];
   }


   for (i=0; i<2; i++)
   {
   	uCal[i]   = 0;
   	uCal[i]   = upStreamBuf[33 + i*3];
   	uCal[i] <<= 8;
   	uCal[i]  += upStreamBuf[34 + i*3];
   	uCal[i] <<= 8;
   	uCal[i]  += upStreamBuf[35 + i*3];

   	dCal[i]   = 0;
   	dCal[i]   = downStreamBuf[33 + i*3 ];
   	dCal[i] <<= 8;
   	dCal[i]  += downStreamBuf[34 + i*3];
   	dCal[i] <<= 8;
   	dCal[i]  += downStreamBuf[35 + i*3];
   }

	  h = 9*0.125e-6 / (uCal[1] - uCal[0]);
	  h = (uTime[0] - uTime[STOP_NUM])*h + uClk[STOP_NUM-1]*0.125e-6;
	h1=h*1000;
	 
	 
g = 9*0.125e-6 / (dCal[1] - dCal[0]);
	  g = (dTime[0] - dTime[STOP_NUM])*g + dClk[STOP_NUM-1]*0.125e-6;
	 g1=g*1000;

calCount= (	uCal[1]-uCal[0])/(10-1);
	CLOCKperiod=(8000000);
	//normLSB=CLOCKperiod/calCount;
LSB=calCount*8000000;
normLSB=1/LSB;
  tof=(uTime[0]*normLSB)+(uClk[STOP_NUM-1]/CLOCKperiod)-(uTime[STOP_NUM]*normLSB);  
 mTOF=tof*1000; 
printf("\n\r--------------------\n\r ");
printf("\n\r method 1 "); 
printf("\n\r");	 
//printf("\n\r TOF= %f s",tof);
//printf("\n\r TOF(in ms)= %f ms",mTOF);
	   // all long int calculaion without floating point
      dmy = (uTime[0] - uTime[STOP_NUM])*140625;
      dn  = uCal[1] - uCal[0];
      us  = dmy / dn;

      ur  = dmy - us*dn;
			HAL_Delay(2000);
      dmy = dn / 2;
      ur  = (ur*8 + dmy);
      ur  = ur / dn;
      us  = 8*us + ur;
      us  = us + uClk[STOP_NUM - 1 ] * 125000;


      dmy = (dTime[0] - dTime[STOP_NUM])*140625;
      dn  = dCal[1] - dCal[0];
      ds  = dmy / dn;
      dr  = dmy - ds*dn;
      dmy = dn / 2;
      dr  = (dr*8 + dmy);
      dr  = dr / dn;
      ds  = 8*ds + dr;
      ds  = ds + dClk[STOP_NUM-1] * 125000;


dtof=h-g;
printf("\n\n\r TOF upstream(in ms)= %f ms",h1);
printf("\n\n\r TOF downstream(in ms)= %f ms",g1);


printf("\n\n\r TOF upstream(msp)= %ld ",us);
printf("\n\n\r TOF downstream(msp)= %ld ",ds);

v1=(dtof*c*c)/(2*l);
Q1=k*v1*A;
printf("\n\n\r Velocity of Water = %Lf m/s\n\n",v1);
printf("\n\n\r Q= %lf m3/s",Q1);
printf("\n\n\r--------------------\n\r ");
 printf("\n\r\n\r method 2\n ");
 
 for (int i = 0; i<6; i++)
 {
	 TOF[i] = 9*0.125e-6 / (uCal[1] - uCal[0]);
	 TOF[i]= (uTime[i] - uTime[i+1])*TOF[i] + uClk[i]*0.125e-6;
	 T12 += TOF[i];
//	 mTOF=TOF[i]*1000;
//	 printf("\n\r UP TOF= %Lf s",TOF[i]);
//	 printf("\n\r UP TOF(in ms)= %Lf ms",mTOF);
 }
 
 T12 = T12/5;  // Upstream TIme of Flight
 printf("\n\r T12 = %Lf \n\n",T12);
  
 for (int i = 0; i<6; i++)
 {
	 TOF[i] = 9*0.125e-6 / (dCal[1] - dCal[0]);
	 TOF[i]= (dTime[i] - dTime[i+1])*TOF[i] + dClk[i]*0.125e-6;
	 T21 += TOF[i];
//	 mTOF=TOF[i]*1000;
//	 printf("\n\r DN TOF= %Lf s",TOF[i]);
//	 printf("\n\r DN TOF(in ms)= %Lf ms",mTOF);
 }
 T21 = T21/5;   // Downstream Time of Flight
 printf("\n\r T21 = %Lf \n\n",T21);
 dTOF = (T21 - T12);
 printf("\n\r dTOF = %Lf \n\n",dTOF);
 vel = 0.031*(dTOF/T21*T12);
 printf("\n\r Velocity of Water = %Lf m/s\n\n",vel);
 flow = (((22/7)*((0.015*0.015)/4))*vel)*1000000;
 printf("\n\r Water Flow = %Lf mL/s \n\n",flow);
printf("\n\r--------------------\n\r ");
flag++;
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 115200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PE11 PE12 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : PE14 */
  GPIO_InitStruct.Pin = GPIO_PIN_14;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : PD12 PD13 PD14 PD15 */
  GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */
void TDC7200_reg_init(void)
{
	b[0]=0x00;
	for(int i=0;i<10;i++)
{
	b[0]|=(0x40);
	b[1]=TDC7200_reg_local_copy[i];
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi2,b ,2, 50);
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
  HAL_Delay(1000);
	b[0]++;
}
  



printf("\n\r TDC7200 Registers After Initialization");
////0x00
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b0[0]=TDC7200_CONFIG1_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b0 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b0[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
printf("\n\r CONFIG1_REG:0x0%x",b0[1]);
HAL_Delay(1000);
////0x01
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b1[0]=TDC7200_CONFIG2_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b1 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b1[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r CONFIG2_REG:0x%x",b1[1]);
HAL_Delay(1000);

////0x02
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b2[0]=TDC7200_INTRPT_STATUS_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b2 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b2[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r INTRPT_STATUS_REG:0x%x",b2[1]);
HAL_Delay(1000);

////0x03

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b3[0]=TDC7200_INTRPT_MASK_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b3 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b3[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r INTRPT_MASK_REG:0x%x",b3[1]);
HAL_Delay(1000);

////0x04

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b4[0]=TDC7200_COARSE_COUNTER_OVH_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b4 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b4[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r COARSE_COUNTER_OVH_REG:0x%x",b4[1]);
HAL_Delay(1000);

////0x05

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b5[0]=TDC7200_COARSE_COUNTER_OVL_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b5 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b5[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r COARSE_COUNTER_OVL_REG:0x%x",b5[1]);
HAL_Delay(1000);

////0x06

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b6[0]=TDC7200_CLOCK_COUNTER_OVH_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b6 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b6[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r CLOCK_COUNTER_OVH_REG:0x%x",b6[1]);
HAL_Delay(1000);

////0x07

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b7[0]=TDC7200_CLOCK_COUNTER_OVL_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b7 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b7[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r CLOCK_COUNTER_OVL_REG:0x%x",b7[1]);
HAL_Delay(1000);

////0x08

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b8[0]=TDC7200_CLOCK_COUNTER_STOP_MASKH_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b8 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b8[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r CLOCK_COUNTER_STOP_MASKH_REG:0x%x",b8[1]);
HAL_Delay(1000);

////0x09

HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
b9[0]=TDC7200_CLOCK_COUNTER_STOP_MASKL_REG ;//| 0x40;;

HAL_SPI_Transmit(&hspi2,b9 ,1, 50);

//HAL_SPI_Transmit(&hspi2,byte_data ,1, 50);

HAL_SPI_Receive(&hspi2,&b9[1],1, 50);
HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);	
printf("\n\r CLOCK_COUNTER_STOP_MASKL_REG:0x%x",b9[1]);
HAL_Delay(1000);

	
	
}	
PUTCHAR_PROTOTYPE
{
  /* Place your implementation of fputc here */
  /* e.g. write a character to the EVAL_COM1 and Loop until the end of transmission */
  HAL_UART_Transmit(&huart6, (uint8_t *)&ch, 1, 0xFFFF);

  return ch;
}
void TDC1000_SPIByteReadReg(uint8_t addr,uint8_t *buffer)
{
	uint8_t RxBuf[2];
RxBuf[0]=addr;
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_15,GPIO_PIN_RESET);
//SPi transmit
HAL_SPI_Transmit(&hspi2,RxBuf,1,50);
HAL_SPI_Receive(&hspi2,buffer,1,50);	
//Bring chip select high
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_15,GPIO_PIN_SET);
	HAL_Delay(500);
}
void TDC1000_SPIByteWriteReg(uint8_t addr, uint8_t value)
{
	uint8_t Buf[2]; 
	Buf[0]=addr;
Buf[0]|=0x40; //Address of control register
Buf[1]=value;//Transmission data
//Bring slave select low.
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_15,GPIO_PIN_RESET);
//SPi transmit
HAL_SPI_Transmit(&hspi2,Buf,2,HAL_MAX_DELAY);
//Bring chip select high
HAL_GPIO_WritePin(GPIOD,GPIO_PIN_15,GPIO_PIN_SET);
	
	HAL_Delay(500);
}
void TDC1000_reg_init(void)
{
	a[0]=0x00;
	for(int i=0;i<10;i++)
{
	a[0]|=(0x40);
	a[1]=TDC1000_reg_local_copy[i];
	TDC1000_SPIByteWriteReg(a[0],a[1]);
  HAL_Delay(1000);
	a[0]++;
}
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
